
(function(){
  function norm(s){return (s||'').toString().trim().toLowerCase().replace(/\s+/g,' ');}
  function toNum(v, def){ var n = parseFloat(v); return isFinite(n) ? n : def; }
  function readPriorityMap(){
    var raw = (document.getElementById('yc-staff-priority')||{}).value || '';
    var map = {};
    if(!raw) return map;
    try {
      var obj = JSON.parse(raw);
      if (obj && typeof obj === 'object') {
        Object.keys(obj).forEach(function(k){ map[norm(k)] = toNum(obj[k], 1e9); });
        return map;
      }
    } catch(e){}
    raw.split(/\r?\n|,/).forEach(function(line){
      var part = line.split('=');
      if(part.length>=2){
        var name = norm(part[0]);
        var pr = toNum(part.slice(1).join('='), 1e9);
        if(name){ map[name] = pr; }
      }
    });
    return map;
  }

  function sortGrid(grid){
    var map = readPriorityMap();
    var cards = Array.prototype.slice.call(grid.querySelectorAll('.yc-staff-card'));
    cards.sort(function(a,b){
      // 1) data-order priority (ascending); if missing -> +inf
      var ao = toNum(a.getAttribute('data-order'), 1e9);
      var bo = toNum(b.getAttribute('data-order'), 1e9);
      if (ao !== bo) return ao - bo;
      // 2) map priority (ascending); if absent -> +inf
      var anEl = a.querySelector('.yc-staff-name'), bnEl = b.querySelector('.yc-staff-name');
      var an = norm(anEl ? anEl.textContent : '');
      var bn = norm(bnEl ? bnEl.textContent : '');
      var ap = (an in map) ? map[an] : 1e9;
      var bp = (bn in map) ? map[bn] : 1e9;
      if (ap !== bp) return ap - bp;
      // 3) alpha fallback (ru)
      return an.localeCompare(bn, 'ru');
    });
    cards.forEach(function(c){ grid.appendChild(c); });
  }

  function ready(fn){ if(document.readyState!=='loading'){ fn(); } else { document.addEventListener('DOMContentLoaded', fn); } }

  ready(function(){
    var grid = document.querySelector('.yc-staff-grid');
    if(!grid) return;
    sortGrid(grid);
  });
})();

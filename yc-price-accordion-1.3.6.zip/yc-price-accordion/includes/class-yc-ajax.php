<?php
if (!defined('ABSPATH')) exit;

class YC_Ajax {

    public static function get_company_staff_from_cache_or_links($company_id, $staff_links){
        $cache_key = 'yc_staff_cache_'.$company_id;
        $ttl = intval(get_option('yc_cache_ttl', 0));
        $cached = get_transient($cache_key);
        if ($cached && is_array($cached)){
            return $cached;
        }

        $rows = [];
        if (isset($staff_links[$company_id]) && is_array($staff_links[$company_id])){
            foreach ($staff_links[$company_id] as $sid => $url){
                $rows[] = ['id'=>intval($sid), 'name'=>'', 'speciality'=>''];
            }
        }

        if (!empty($rows)){
            if ($ttl > 0) set_transient($cache_key, $rows, $ttl * MINUTE_IN_SECONDS);
            return $rows;
        }

        $rows = self::fetch_staff_from_yc_api($company_id);
        if (is_wp_error($rows)) return [];
        if (is_array($rows) && !empty($rows)){
            if ($ttl > 0) set_transient($cache_key, $rows, $ttl * MINUTE_IN_SECONDS);
            return $rows;
        }
        return [];
    }

    public static function refresh_company_staff_cache($company_id){
        $rows = self::fetch_staff_from_yc_api($company_id);
        if (is_wp_error($rows)) return $rows;
        if (is_array($rows)){
            $cache_key = 'yc_staff_cache_'.$company_id;
            delete_transient($cache_key);
            $ttl = intval(get_option('yc_cache_ttl', 0));
            if ($ttl > 0) {
                set_transient($cache_key, $rows, $ttl * MINUTE_IN_SECONDS);
            }
            return $rows;
        }
        return new WP_Error('yc_empty', 'Пустой ответ YClients');
    }

    private static function fetch_staff_from_yc_api($company_id){
        $token   = get_option('yc_yc_token', '');
        $partner = get_option('yc_yc_partner_token', '');
        if (empty($token)){
            return new WP_Error('yc_token', 'Токен YClients не задан');
        }
        $url = 'https://api.yclients.com/api/v1/company/'.intval($company_id).'/staff';
        $args = [
            'headers' => [
                'Authorization' => 'Bearer '.$token,
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
            ],
            'timeout' => 20,
        ];
        if (!empty($partner)){
            $args['headers']['Partner-Token'] = $partner;
        }
        $res = wp_remote_get($url, $args);
        if (is_wp_error($res)) return $res;
        $code = wp_remote_retrieve_response_code($res);
        $body = wp_remote_retrieve_body($res);
        if ($code < 200 || $code >= 300){
            return new WP_Error('yc_http', 'HTTP '.$code.': '.$body);
        }
        $data = json_decode($body, true);
        $out = [];
        if (is_array($data)){
            $list = isset($data['data']) ? $data['data'] : $data;
            foreach ($list as $row){
                if (!isset($row['id'])) continue;
                $out[] = [
                    'id' => intval($row['id']),
                    'name' => trim(($row['name'] ?? '')),
                    'speciality' => trim(($row['specialization'] ?? ($row['position'] ?? ''))),
                ];
            }
        }
        return $out;
    }
}

add_action('wp_ajax_yc_refresh_staff_cache', function(){
    if (!current_user_can('manage_options')) wp_send_json_error(['message'=>'forbidden'], 403);
    check_ajax_referer('yc_refresh_staff','nonce');

    $branches = get_option('yc_branches', []);
    if (!is_array($branches) || empty($branches)) wp_send_json_error(['message'=>'no branches']);

    $result = [];
    foreach ($branches as $b){
        $cid = intval($b['id']);
        if (!$cid) continue;
        $rows = YC_Ajax::refresh_company_staff_cache($cid);
        if (is_wp_error($rows)){
            $result[$cid] = ['ok'=>false, 'error'=>$rows->get_error_message()];
        } else {
            $result[$cid] = ['ok'=>true, 'count'=>count($rows)];
        }
    }
    wp_send_json_success($result);
});

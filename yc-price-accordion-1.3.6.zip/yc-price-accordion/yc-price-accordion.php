<?php
/*
Plugin Name: YC Price Accordion
Description: Прайс + Специалисты (YClients). Сохранение ссылок на страницы специалистов и ручной порядок вывода. Кэш + кнопка обновления из YClients.
Version: 1.3.6
Author: ChatGPT
*/

if (!defined('ABSPATH')) { exit; }

define('YC_PA_VERSION', '1.3.6');
define('YC_PA_SLUG', 'yc-price-settings');

require_once plugin_dir_path(__FILE__). 'includes/class-yc-ajax.php';
require_once plugin_dir_path(__FILE__). 'admin/class-yc-admin.php';

add_action('init', function() {
    load_plugin_textdomain('yc-price-accordion', false, dirname(plugin_basename(__FILE__)).'/languages');
});

add_action('admin_menu', function() {
    add_options_page(
        __('Настройки YClients', 'yc-price-accordion'),
        __('YC Price', 'yc-price-accordion'),
        'manage_options',
        YC_PA_SLUG,
        ['YC_Admin','render_settings_page']
    );
});

add_action('admin_init', function() {
    register_setting('yc_price_group','yc_branches', ['type'=>'array', 'sanitize_callback'=>'YC_Admin::sanitize_branches']);
    register_setting('yc_price_group','yc_cache_ttl', ['type'=>'integer','default'=>0]);
    register_setting('yc_price_group','yc_debug', ['type'=>'boolean','default'=>false]);
    register_setting('yc_price_group','yc_multi_categories', ['type'=>'boolean','default'=>false]);
    register_setting('yc_price_group','yc_show_staff', ['type'=>'boolean','default'=>true]);
    register_setting('yc_price_group','yc_title_staff', ['type'=>'string','default'=>'Специалисты']);
    register_setting('yc_price_group','yc_title_price', ['type'=>'string','default'=>'Прайс-лист']);
    register_setting('yc_price_group','yc_book_url_tpl', ['type'=>'string','default'=>'']);
    register_setting('yc_price_group','yc_book_step', ['type'=>'string','default'=>'select-master']);
    register_setting('yc_price_group','yc_utm_source', ['type'=>'string','default'=>'site']);
    register_setting('yc_price_group','yc_utm_medium', ['type'=>'string','default'=>'price']);
    register_setting('yc_price_group','yc_utm_campaign', ['type'=>'string','default'=>'booking']);
    register_setting('yc_price_group','yc_vlist_page', ['type'=>'integer','default'=>15]);

    register_setting('yc_price_group','yc_yc_token', ['type'=>'string','default'=>'']);
    register_setting('yc_price_group','yc_yc_partner_token', ['type'=>'string','default'=>'']);

    register_setting('yc_price_group','yc_staff_links', ['type'=>'array', 'default'=>[] ]);
    register_setting('yc_price_group','yc_staff_order', ['type'=>'array', 'default'=>[] ]);
});

add_action('admin_enqueue_scripts', function($hook){
    if ($hook !== 'settings_page_'.YC_PA_SLUG) return;
    wp_enqueue_style('yc-admin', plugin_dir_url(__FILE__).'admin/css/yc-admin.css', [], YC_PA_VERSION);
    wp_enqueue_script('yc-admin', plugin_dir_url(__FILE__).'admin/js/yc-admin.js', ['jquery'], YC_PA_VERSION, true);
    wp_localize_script('yc-admin', 'ycAdmin', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('yc_refresh_staff'),
        'confirm' => __('Обновить кэш специалистов из YClients для всех филиалов?', 'yc-price-accordion'),
    ]);
});

add_action('yc_warm_staff_cache', function(){
    $branches = get_option('yc_branches', []);
    if (!is_array($branches)) return;
    foreach ($branches as $row) {
        if (empty($row['id'])) continue;
        YC_Ajax::refresh_company_staff_cache(intval($row['id']));
    }
});
add_action('updated_option', function($option, $old, $new){
    if ($option === 'yc_cache_ttl') {
        if (intval($new) > 0 && !wp_next_scheduled('yc_warm_staff_cache')) {
            wp_schedule_event(time()+60, 'ten_minutes', 'yc_warm_staff_cache');
        } else if (intval($new) <= 0) {
            $ts = wp_next_scheduled('yc_warm_staff_cache');
            if ($ts) wp_unschedule_event($ts, 'yc_warm_staff_cache');
        }
    }
},10,3);
add_filter('cron_schedules', function($s) {
    $s['ten_minutes'] = ['interval'=>600,'display'=>'Every 10 Minutes'];
    return $s;
});

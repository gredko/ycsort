<?php
if (!defined('ABSPATH')) exit;

class YC_Admin {
  public static function boot(){
    add_action('admin_menu', [__CLASS__, 'menu']);
    add_action('admin_init', [__CLASS__, 'settings']);
  }
  public static function menu(){
    add_options_page('YClients Прайс (Кеш)','YClients Прайс (Кеш)','manage_options','yc-price-settings',[__CLASS__,'render_page']);
  }
  public static function settings(){
    register_setting('yc_price_group', 'yc_staff_priority_id_map', [
        'type'=>'string',
        'sanitize_callback'=>function($v){ return is_string($v)?$v:''; },
        'default'=>''
    ]);
    register_setting('yc_price_group', 'yc_cache_ttl', [
        'type'=>'integer',
        'sanitize_callback'=>function($v){ $v=intval($v); return ($v>=1 && $v<=1440)?$v:30; },
        'default'=>30
    ]);
    register_setting('yc_price_group', 'yc_manual_staff_json', [
        'type'=>'string',
        'sanitize_callback'=>function($v){ return (string)$v; },
        'default'=>''
    ]);
  }
  public static function render_page(){
    if (!current_user_can('manage_options')) return;
    if (!empty($_POST['yc_seed_cache']) ){
        check_admin_referer('yc_price_group-options');
        $ok = YC_API::seed_cache_from_json( (string)($_POST['yc_manual_staff_json'] ?? '') );
        add_settings_error('yc-price-settings','yc_seed', $ok ? 'Кеш сохранён из JSON.' : 'Неверный JSON.', $ok?'updated':'error');
    }
    if (!empty($_POST['yc_refresh_cache']) ){
        check_admin_referer('yc_price_group-options');
        $ok = YC_API::refresh_cache(5);
        add_settings_error('yc-price-settings','yc_refresh', $ok ? 'Кеш обновлён из источника.' : 'Не удалось обновить кеш из источника.', $ok?'updated':'error');
    }
    settings_errors('yc-price-settings');
    $last = get_option('yc_cache_last_updated','—');
    ?>
    <div class="wrap yc-admin-card">
      <h2>YClients Прайс — кеш и сортировка</h2>
      <form method="post" action="options.php">
        <?php settings_fields('yc_price_group'); ?>
        <table class="form-table">
          <tr>
            <th scope="row">Приоритеты сотрудников по ID</th>
            <td>
              <textarea name="yc_staff_priority_id_map" class="large-text code" rows="6" placeholder="12345=1&#10;67890=2"><?php echo esc_textarea(get_option('yc_staff_priority_id_map','')); ?></textarea>
              <p class="description">Формат: <code>staff_id=порядок</code> по строкам или JSON. Меньше — выше.</p>
            </td>
          </tr>
          <tr>
            <th scope="row">TTL кеша (минуты)</th>
            <td><input type="number" class="small-text" min="1" max="1440" name="yc_cache_ttl" value="<?php echo intval(get_option('yc_cache_ttl',30)); ?>"></td>
          </tr>
          <tr>
            <th scope="row">Ручной ввод сотрудников (JSON)</th>
            <td>
              <textarea name="yc_manual_staff_json" class="large-text code" rows="10" placeholder='[{"id":98771,"name":"ФИО","position":"Должность","photo":"https://...","order":1}]'><?php echo esc_textarea(get_option('yc_manual_staff_json','')); ?></textarea>
              <p class="description">Можно вставить массив сотрудников или объект с ключом <code>staff</code>. Кнопка ниже сохранит кеш напрямую из этого JSON.</p>
            </td>
          </tr>
        </table>
        <?php submit_button(); ?>
        <h3>Управление кешем</h3>
        <p>Последнее обновление кеша: <strong><?php echo esc_html($last); ?></strong></p>
        <p>
          <?php wp_nonce_field('yc_price_group-options'); ?>
          <button name="yc_refresh_cache" value="1" class="button button-primary">Обновить кеш из источника</button>
          <button name="yc_seed_cache" value="1" class="button">Сохранить кеш из JSON</button>
        </p>
      </form>
    </div>
    <?php
  }
}

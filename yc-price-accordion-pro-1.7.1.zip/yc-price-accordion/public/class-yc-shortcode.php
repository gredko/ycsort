<?php
if (!defined('ABSPATH')) exit;

class YC_Shortcode {
  public static function init(){
    add_shortcode('yclients_price', [__CLASS__,'render']);
    add_action('wp_enqueue_scripts', [__CLASS__,'assets']);
  }
  public static function assets(){
    wp_register_style('yc-price-public', YC_PA_URL . 'public/yc-price-public.css', array(), YC_PA_VER);
    wp_enqueue_style('yc-price-public');
  }

  private static function norm($s){ $s = wp_strip_all_tags((string)$s); return preg_replace('/\s+/u',' ', trim(mb_strtolower($s,'UTF-8'))); }
  private static function parse_id_priority_map(){
    $raw = get_option('yc_staff_priority_id_map',''); $out = array();
    if (is_array($raw)){ foreach ($raw as $k=>$v){ $out[(string)$k] = floatval($v);} return $out; }
    $raw = (string)$raw; if (!$raw) return $out;
    if ($raw[0]==='{'){ $obj = json_decode($raw,true); if (is_array($obj)){ foreach($obj as $k=>$v){ $out[(string)$k]=floatval($v);} return $out; } }
    $lines = preg_split('/\r?\n|,/', $raw);
    foreach ($lines as $line){ $p = explode('=', $line, 2); if (count($p)==2){ $out[trim($p[0])] = floatval($p[1]); } }
    return $out;
  }
  private static function sort_staff_by_id($items){
    $map = self::parse_id_priority_map();
    usort($items, function($a,$b) use ($map){
      $ao = isset($a['order']) ? floatval($a['order']) : 1e9;
      $bo = isset($b['order']) ? floatval($b['order']) : 1e9;
      if ($ao !== $bo) return $ao <=> $bo;
      $aid = isset($a['id']) ? (string)$a['id'] : '';
      $bid = isset($b['id']) ? (string)$b['id'] : '';
      $ap = isset($map[$aid]) ? $map[$aid] : 1e9;
      $bp = isset($map[$bid]) ? $map[$bid] : 1e9;
      if ($ap !== $bp) return $ap <=> $bp;
      $an = isset($a['name']) ? self::norm($a['name']) : '';
      $bn = isset($b['name']) ? self::norm($b['name']) : '';
      return strcoll($an, $bn);
    });
    return $items;
  }

  public static function render($atts = [], $content = ''){
    ob_start();
    $data = class_exists('YC_API') ? YC_API::get_cached_price() : null;
    if (!$data){
        echo '<div class="yc-price-warning">Кеш пуст. Зайдите в админку → вставьте JSON сотрудников или нажмите «Обновить кеш».</div>';
        return ob_get_clean();
    }
    $staff = isset($data['staff']) && is_array($data['staff']) ? $data['staff'] : array();
    $staff = self::sort_staff_by_id($staff);

    echo '<div class="yc-staff-section"><div class="yc-staff-grid-wrap"><div class="yc-block-title">Специалисты</div>';
    echo '<div class="yc-staff-grid" data-ycpa-version="'.esc_attr(YC_PA_VER).'">';
    foreach ($staff as $s){
        $id = esc_attr($s['id'] ?? '');
        $name = esc_html($s['name'] ?? '');
        $pos = esc_html($s['position'] ?? '');
        $photo = esc_url($s['photo'] ?? '');
        $order = isset($s['order']) ? floatval($s['order']) : 1e9;
        echo '<div class="yc-staff-card" data-order="'.esc_attr($order).'" data-id="'.$id.'">';
        echo '<a class="yc-staff-photo">'.($photo?'<img src="'.$photo.'" alt="">':'').'</a>';
        echo '<div class="yc-staff-meta"><div class="yc-staff-name">'.$name.'</div><div class="yc-staff-pos">'.$pos.'</div></div>';
        echo '</div>';
    }
    echo '</div></div></div>';
    return ob_get_clean();
  }
}

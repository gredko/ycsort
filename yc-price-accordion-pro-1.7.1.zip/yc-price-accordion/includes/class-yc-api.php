<?php
if (!defined('ABSPATH')) exit;

class YC_API {
    public static function cache_key(){
        $branches = get_option('yc_branches', array());
        $hash = md5(json_encode($branches));
        return 'yc_price_cache_' . $hash;
    }
    public static function get_cached_price(){
        $key = self::cache_key();
        $cached = get_transient($key);
        return (is_array($cached) ? $cached : null);
    }
    public static function set_cached_price($data){
        $key = self::cache_key();
        $ttl = intval(get_option('yc_cache_ttl', 30)); if ($ttl < 1) $ttl = 30;
        set_transient($key, $data, $ttl * MINUTE_IN_SECONDS);
        update_option('yc_cache_last_updated', current_time('mysql'));
    }
    public static function seed_cache_from_json($raw){
        $raw = trim((string)$raw);
        if (!$raw) return false;
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) return false;
        if (isset($decoded['staff']) || isset($decoded['services'])){
            $data = array('staff'=>array(), 'services'=>array());
            if (isset($decoded['staff']) && is_array($decoded['staff'])) $data['staff'] = $decoded['staff'];
            if (isset($decoded['services']) && is_array($decoded['services'])) $data['services'] = $decoded['services'];
            self::set_cached_price($data);
            return true;
        } else {
            self::set_cached_price(array('staff'=>$decoded,'services'=>array()));
            return true;
        }
    }
    public static function refresh_cache($timeout = 5){
        $data = apply_filters('ycpa_refresh_cache_data', null);
        if (is_array($data) && (isset($data['staff']) || isset($data['services']))){
            if (!isset($data['staff'])) $data['staff'] = array();
            if (!isset($data['services'])) $data['services'] = array();
            self::set_cached_price($data);
            return true;
        }
        return false;
    }
}

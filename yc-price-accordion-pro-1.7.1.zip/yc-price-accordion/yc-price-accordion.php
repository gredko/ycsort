<?php
/**
 * Plugin Name: YClients Price Accordion Pro
 * Description: Кешированный вывод прайса и списка сотрудников YClients. Сортировка по ID на бэке.
 * Version: 1.7.1
 * Author: ChatGPT
 * License: GPLv2 or later
 */
if (!defined('ABSPATH')) exit;

define('YC_PA_VER','1.7.1');
define('YC_PA_DIR', plugin_dir_path(__FILE__));
define('YC_PA_URL', plugin_dir_url(__FILE__));
define('YC_PA_CACHE_GROUP', 'yc_price_cache');

add_action('init', function(){
    load_plugin_textdomain('yc-price-accordion', false, dirname(plugin_basename(__FILE__)).'/languages/');
});

require_once YC_PA_DIR.'includes/class-yc-api.php';
require_once YC_PA_DIR.'public/class-yc-shortcode.php';
require_once YC_PA_DIR.'admin/class-yc-admin.php';

add_action('plugins_loaded', function(){
    YC_Shortcode::init();
    YC_Admin::boot();
});

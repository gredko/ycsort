<?php
namespace YC;

if (!defined('ABSPATH')) { exit; }

class Admin {

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'assets']);
    }

    public static function menu() {
        add_options_page(
            __('YC Price Settings', 'yc-price-accordion'),
            __('YC Price', 'yc-price-accordion'),
            'manage_options',
            'yc-price-settings',
            [__CLASS__, 'render_settings']
        );
    }

    public static function assets($hook) {
        if ($hook !== 'settings_page_yc-price-settings') return;
        wp_enqueue_style('ycpa-admin', plugins_url('admin/css/admin.css', dirname(__FILE__)), [], YCPA_VER);
        wp_enqueue_script('ycpa-admin', plugins_url('admin/js/admin.js', dirname(__FILE__)), ['jquery'], YCPA_VER, true);
    }

    public static function register_settings() {
        // Основная группа настроек
        register_setting('yc_price_group', 'yc_branches', [
            'type' => 'array',
            'sanitize_callback' => [__CLASS__, 'sanitize_branches'],
        ]);
        register_setting('yc_price_group', 'yc_cache_ttl', ['type' => 'integer', 'sanitize_callback' => 'absint']);
        register_setting('yc_price_group', 'yc_debug', ['type' => 'boolean', 'sanitize_callback' => [__CLASS__, 'sanitize_bool']]);
        register_setting('yc_price_group', 'yc_multi_categories', ['type' => 'boolean', 'sanitize_callback' => [__CLASS__, 'sanitize_bool']]);
        register_setting('yc_price_group', 'yc_show_staff', ['type' => 'boolean', 'sanitize_callback' => [__CLASS__, 'sanitize_bool']]);
        register_setting('yc_price_group', 'yc_title_staff', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);
        register_setting('yc_price_group', 'yc_title_price', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);
        register_setting('yc_price_group', 'yc_book_url_tpl', ['type' => 'string', 'sanitize_callback' => 'esc_url_raw']);
        register_setting('yc_price_group', 'yc_book_step', ['type' => 'string', 'sanitize_callback' => [__CLASS__, 'sanitize_book_step']]);
        register_setting('yc_price_group', 'yc_utm_source', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);
        register_setting('yc_price_group', 'yc_utm_medium', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);
        register_setting('yc_price_group', 'yc_utm_campaign', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);
        register_setting('yc_price_group', 'yc_vlist_page', ['type' => 'integer', 'sanitize_callback' => 'absint']);

        // Ссылки на специалистов (массив [branchId][staffId] => url)
        register_setting('yc_price_group', 'yc_staff_links', [
            'type' => 'array',
            'sanitize_callback' => [__CLASS__, 'sanitize_staff_links'],
        ]);

        // Ручной порядок (ключевая правка)
        register_setting('yc_price_group', 'yc_staff_order', [
            'type' => 'array',
            'sanitize_callback' => [__CLASS__, 'sanitize_staff_order'],
        ]);
    }

    /* ===== Sanitizers ===== */

    public static function sanitize_bool($v) {
        return (isset($v) && (string)$v === '1') ? 1 : 0;
    }

    public static function sanitize_book_step($v) {
        $v = is_string($v) ? $v : '';
        return in_array($v, ['select-master', 'select-services'], true) ? $v : 'select-master';
    }

    public static function sanitize_branches($input) {
        if (!is_array($input)) return [];
        $out = [];
        foreach ($input as $row) {
            $id    = isset($row['id']) ? absint($row['id']) : 0;
            $title = isset($row['title']) ? sanitize_text_field($row['title']) : '';
            $url   = isset($row['url']) ? esc_url_raw($row['url']) : '';
            if ($id > 0 && $title !== '') {
                $out[] = ['id' => $id, 'title' => $title, 'url' => $url];
            }
        }
        return array_values($out);
    }

    public static function sanitize_staff_links($input) {
        if (!is_array($input)) return [];
        $out = [];
        foreach ($input as $branchId => $map) {
            $b = preg_replace('~\D~', '', (string)$branchId);
            if ($b === '') continue;
            $out[$b] = [];
            if (!is_array($map)) continue;
            foreach ($map as $staffId => $url) {
                $s = preg_replace('~\D~', '', (string)$staffId);
                if ($s === '') continue;
                $url = is_string($url) ? trim($url) : '';
                $out[$b][$s] = esc_url_raw($url);
            }
        }
        return $out;
    }

    public static function sanitize_staff_order($input) {
        // Ожидаем массив: [branchId => "id1,id2=5,id3"]
        if (!is_array($input)) return [];
        $out = [];
        foreach ($input as $branchId => $txt) {
            $branchId = preg_replace('~\D~', '', (string)$branchId);
            if ($branchId === '') continue;
            $txt = is_string($txt) ? trim($txt) : '';
            // только цифры, запятые, равно и пробелы
            $txt = preg_replace('~[^0-9,=\s]+~u', '', $txt);
            // Сводим подряд идущие пробелы к одному
            $txt = preg_replace('~\s+~', ' ', $txt);
            $out[$branchId] = $txt;
        }
        return $out;
    }

    /* ===== Settings Page ===== */

    public static function render_settings() {
        if (!current_user_can('manage_options')) return;

        $branches      = get_option('yc_branches', []);
        $cache_ttl     = get_option('yc_cache_ttl', 0);
        $debug         = (int) get_option('yc_debug', 0);
        $multi_cat     = (int) get_option('yc_multi_categories', 0);
        $show_staff    = (int) get_option('yc_show_staff', 1);
        $title_staff   = (string) get_option('yc_title_staff', 'Специалисты');
        $title_price   = (string) get_option('yc_title_price', 'Прайс-лист');
        $book_url_tpl  = (string) get_option('yc_book_url_tpl', '');
        $book_step     = (string) get_option('yc_book_step', 'select-master');
        $utm_source    = (string) get_option('yc_utm_source', 'site');
        $utm_medium    = (string) get_option('yc_utm_medium', 'price');
        $utm_campaign  = (string) get_option('yc_utm_campaign', 'booking');
        $vlist_page    = (int) get_option('yc_vlist_page', 15);

        $staff_links   = get_option('yc_staff_links', []); // [branchId][staffId] => url
        $staff_order   = get_option('yc_staff_order', []); // [branchId] => "id1,id2=5,id3"

        // Для рендера таблиц специалистов нужно знать список сотрудников.
        // Берём по ключам из yc_staff_links, чтобы не зависеть от API.
        $staff_by_branch = [];
        foreach ($staff_links as $bId => $map) {
            $staff_by_branch[$bId] = [];
            foreach ($map as $sId => $url) {
                $staff_by_branch[$bId][] = [
                    'id' => (string)$sId,
                    'name' => '',       // Имя неизвестно без API; оставим пустым — пользователь вбивает ссылку
                    'position' => '',
                    'url' => $url,
                ];
            }
            // Если совсем пусто — оставим пустую таблицу с подсказкой
        }

        // Помогаем совместимости со старыми установками: если в настройках уже есть фирмы,
        // покажем их; иначе — один пример.
        if (empty($branches)) {
            $branches = [
                ['id' => 1181603, 'title' => 'GARDENIA SPA (Зубовская 7)', 'url' => ''],
                ['id' => 560533,  'title' => 'GARDENIA (Погодинская 2)', 'url' => ''],
            ];
        }

        ?>
        <div class="wrap">
          <h1 style="margin-bottom:12px;"><?php echo esc_html__('Настройки YClients', 'yc-price-accordion'); ?></h1>
          <div class="yc-admin-card">
            <form method="post" action="options.php">
              <?php settings_fields('yc_price_group'); ?>
              <h2><?php echo esc_html__('Настройки YClients', 'yc-price-accordion'); ?></h2>

              <table class="form-table" role="presentation">
                <tbody>
                  <tr>
                    <th scope="row">Филиалы</th>
                    <td>
                      <div id="yc-branches-wrap">
                        <table class="widefat striped yc-admin-table">
                          <thead>
                            <tr>
                              <th style="width:150px;">Company ID</th>
                              <th>Название филиала</th>
                              <th>URL онлайн-записи (можно только домен)</th>
                              <th style="width:120px;">Действие</th>
                            </tr>
                          </thead>
                          <tbody id="yc-branches-body">
                            <?php foreach ($branches as $i => $br): ?>
                              <tr>
                                <td><input class="regular-text" type="number" min="1" name="yc_branches[<?php echo $i; ?>][id]" value="<?php echo esc_attr($br['id']); ?>" required></td>
                                <td><input class="regular-text" type="text" name="yc_branches[<?php echo $i; ?>][title]" value="<?php echo esc_attr($br['title']); ?>" required></td>
                                <td><input class="regular-text" type="text" placeholder="https://nXXXX.yclients.com/" name="yc_branches[<?php echo $i; ?>][url]" value="<?php echo esc_attr($br['url']); ?>"></td>
                                <td><button type="button" class="button button-secondary yc-remove-row">Удалить</button></td>
                              </tr>
                            <?php endforeach; ?>
                          </tbody>
                        </table>
                        <p><button type="button" class="button button-primary" id="yc-add-row">Добавить филиал</button></p>
                        <p class="description">Можно указать только домен — плагин сам соберёт ссылку: <code>/company/{company_id}/personal/{book_step}?o=s{service_id}</code></p>
                      </div>
                    </td>
                  </tr>

                  <tr>
                    <th scope="row">Кэш, минут</th>
                    <td>
                      <input type="number" min="0" style="width:120px;" name="yc_cache_ttl" value="<?php echo esc_attr($cache_ttl); ?>">
                      <p class="description">0 — отключить кэш. Крон раз в 10 минут прогревает кэш по всем филиалам.</p>
                    </td>
                  </tr>

                  <tr>
                    <th scope="row">Временный debug</th>
                    <td><label><input type="checkbox" name="yc_debug" value="1" <?php checked($debug, 1); ?>> Показать отладку на витрине (только для админов).</label></td>
                  </tr>
                  <tr>
                    <th scope="row">Фильтр по нескольким категориям</th>
                    <td><label><input type="checkbox" name="yc_multi_categories" value="1" <?php checked($multi_cat, 1); ?>> Разрешить атрибут шорткода <code>category_ids</code> (через запятую).</label></td>
                  </tr>
                  <tr>
                    <th scope="row">Показывать блок «Специалисты»</th>
                    <td><label><input type="checkbox" name="yc_show_staff" value="1" <?php checked($show_staff, 1); ?>> Показывать блок «Специалисты»</label></td>
                  </tr>

                  <tr>
                    <th scope="row">Заголовки блоков</th>
                    <td>
                      <div style="display:flex;gap:10px;flex-wrap:wrap">
                        <label>«Специалисты»
                          <input type="text" style="width:260px;margin-left:6px" name="yc_title_staff" value="<?php echo esc_attr($title_staff); ?>">
                        </label>
                        <label>«Прайс-лист»
                          <input type="text" style="width:260px;margin-left:6px" name="yc_title_price" value="<?php echo esc_attr($title_price); ?>">
                        </label>
                      </div>
                    </td>
                  </tr>

                  <tr>
                    <th scope="row">Шаблон URL записи</th>
                    <td>
                      <input type="text" class="regular-text code" style="width:100%;" name="yc_book_url_tpl" value="<?php echo esc_attr($book_url_tpl); ?>">
                      <p class="description">Можно указать только домен (например, https://n1295696.yclients.com/). Плейсхолдеры: {company_id}, {service_id}, {book_step}, {utm_*}.</p>
                    </td>
                  </tr>

                  <tr>
                    <th scope="row">Шаг на YClients</th>
                    <td>
                      <fieldset>
                        <label><input type="radio" name="yc_book_step" value="select-master" <?php checked($book_step, 'select-master'); ?>> Сразу выбор мастера</label><br>
                        <label><input type="radio" name="yc_book_step" value="select-services" <?php checked($book_step, 'select-services'); ?>> Сначала выбор услуги</label>
                      </fieldset>
                    </td>
                  </tr>

                  <tr>
                    <th scope="row">UTM source/medium/campaign</th>
                    <td>
                      <input type="text" style="width:180px;margin-right:6px;" name="yc_utm_source" value="<?php echo esc_attr($utm_source); ?>" placeholder="utm_source">
                      <input type="text" style="width:180px;margin-right:6px;" name="yc_utm_medium" value="<?php echo esc_attr($utm_medium); ?>" placeholder="utm_medium">
                      <input type="text" style="width:220px;" name="yc_utm_campaign" value="<?php echo esc_attr($utm_campaign); ?>" placeholder="utm_campaign">
                    </td>
                  </tr>

                  <tr>
                    <th scope="row">Ленивая подгрузка — порция</th>
                    <td>
                      <input type="number" min="5" max="100" style="width:120px;" name="yc_vlist_page" value="<?php echo esc_attr($vlist_page); ?>">
                      <p class="description">Сколько услуг показывать сразу. Остальные — «Показать ещё».</p>
                    </td>
                  </tr>
                </tbody>
              </table>

              <h2>Ссылки на страницы специалистов</h2>
              <table class="form-table" role="presentation">
                <tbody>
                  <tr>
                    <th scope="row">Специалисты по филиалам</th>
                    <td>
                      <div class="yc-admin-card">
                        <p class="description">Укажите ссылки на страницы специалистов на сайте. Список подгружается из YClients (по API) или из уже сохранённых ссылок.</p>
                        <?php
                        // Отрисовываем по веткам из $branches (если есть), иначе по ключам в $staff_links
                        $branches_indexed = [];
                        foreach ($branches as $br) {
                            $branches_indexed[(string)$br['id']] = $br['title'];
                        }

                        $branch_ids = array_unique(array_merge(
                            array_map(fn($b) => (string)$b['id'], $branches),
                            array_keys($staff_links)
                        ));

                        foreach ($branch_ids as $bId):
                            $title = isset($branches_indexed[$bId]) ? $branches_indexed[$bId] : ('Company ' . $bId);
                            echo '<h3 style="margin-top:12px;">' . esc_html($title) . '</h3>';
                            echo '<table class="widefat striped"><thead><tr><th style="width:60px;">ID</th><th>Имя</th><th>Должность</th><th>Ссылка</th></tr></thead><tbody>';

                            // Если есть сохранённые ссылки — покажем их; имя/должность пустые (API недоступен)
                            if (!empty($staff_links[$bId]) && is_array($staff_links[$bId])) {
                                foreach ($staff_links[$bId] as $sId => $url) {
                                    echo '<tr>';
                                    echo '<td>' . esc_html($sId) . '</td>';
                                    echo '<td></td>';
                                    echo '<td></td>';
                                    echo '<td><input type="text" class="regular-text" name="yc_staff_links[' . esc_attr($bId) . '][' . esc_attr($sId) . ']" value="' . esc_attr($url) . '" placeholder="https://example.com/staff/..."></td>';
                                    echo '</tr>';
                                }
                            } else {
                                echo '<tr><td colspan="4"><em>Нет данных для филиала ' . esc_html($bId) . '. Добавьте строки вручную: <code>yc_staff_links[' . esc_html($bId) . '][ID]</code>.</em></td></tr>';
                            }
                            echo '</tbody></table>';
                        endforeach;
                        ?>
                      </div>

                      <div id="yc_manual_order_block" class="yc-admin-card">
                        <h3 style="margin-top:16px;">Ручной порядок специалистов</h3>
                        <p class="description">Для каждого филиала укажите порядок. Формат: <code>id1,id2,id3</code> (id1=первый) или c весами: <code>id1=1,id2=5</code>. Неуказанные — в конце.</p>
                        <?php foreach ($branch_ids as $bId):
                            $title = isset($branches_indexed[$bId]) ? $branches_indexed[$bId] : ('Company ' . $bId);
                            $val = isset($staff_order[$bId]) ? (string)$staff_order[$bId] : '';
                        ?>
                          <h4 style="margin:10px 0 6px;"><?php echo esc_html($title); ?> (ID <?php echo esc_html($bId); ?>)</h4>
                          <textarea name="yc_staff_order[<?php echo esc_attr($bId); ?>]" rows="3" style="width:100%;font-family:monospace;"><?php echo esc_textarea($val); ?></textarea>
                        <?php endforeach; ?>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>

              <p class="submit">
                <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_attr__('Сохранить изменения'); ?>">
              </p>
            </form>
          </div>
        </div>
        <?php
    }
}

(function($){
  $(document).on('click', '#yc-add-row', function(e){
    e.preventDefault();
    var $tbody = $('#yc-branches-body');
    var idx = $tbody.find('tr').length;
    var row = '<tr>'
      + '<td><input class="regular-text" type="number" min="1" name="yc_branches['+idx+'][id]" value="" required></td>'
      + '<td><input class="regular-text" type="text" name="yc_branches['+idx+'][title]" value="" required></td>'
      + '<td><input class="regular-text" type="text" placeholder="https://nXXXX.yclients.com/" name="yc_branches['+idx+'][url]" value=""></td>'
      + '<td><button type="button" class="button button-secondary yc-remove-row">Удалить</button></td>'
      + '</tr>';
    $tbody.append(row);
  });

  $(document).on('click', '.yc-remove-row', function(e){
    e.preventDefault();
    $(this).closest('tr').remove();
    // reindex
    $('#yc-branches-body tr').each(function(i,tr){
      $(tr).find('input').each(function(){
        var name = $(this).attr('name');
        if(!name) return;
        name = name.replace(/yc_branches\[\d+\]/, 'yc_branches['+i+']');
        $(this).attr('name', name);
      });
    });
  });
})(jQuery);

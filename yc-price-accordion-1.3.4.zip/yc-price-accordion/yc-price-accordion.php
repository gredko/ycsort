<?php
/**
 * Plugin Name: YC Price Accordion
 * Description: Прайс-аккордеон YClients + блок "Специалисты". Настройки: филиалы, ссылки на специалистов, UTM, кэш, ручной порядок.
 * Version: 1.3.4
 * Author: Gardenia Dev
 * Text Domain: yc-price-accordion
 */

if (!defined('ABSPATH')) { exit; }

define('YCPA_VER', '1.3.4');
define('YCPA_PATH', plugin_dir_path(__FILE__));
define('YCPA_URL', plugin_dir_url(__FILE__));

require_once YCPA_PATH . 'admin/class-yc-admin.php';

add_action('plugins_loaded', function () {
    \YC\Admin::init();
});

<?php
/**
 * Plugin Name: YC Price Accordion
 * Description: Прайс-лист YClients + блок специалистов. Ссылки и ручной порядок сотрудников на одной странице настроек.
 * Version: 1.3.7
 * Author: ChatGPT
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define('YC_PA_VERSION', '1.3.7');
define('YC_PA_SLUG', 'yc-price-settings');
define('YC_PA_AJAX', 'yc_refresh_staff');
define('YC_PA_CAP', 'manage_options');

// Enqueue admin assets
add_action('admin_enqueue_scripts', function($hook){
    if ( $hook !== 'settings_page_' . YC_PA_SLUG ) return;
    wp_enqueue_script('yc-pa-admin', plugins_url('assets/admin.js', __FILE__), ['jquery'], YC_PA_VERSION, true);
    wp_localize_script('yc-pa-admin', 'YC_PA', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('yc-pa-ajax'),
    ]);
    wp_enqueue_style('yc-pa-admin', plugins_url('assets/admin.css', __FILE__), [], YC_PA_VERSION);
});

// Admin page
add_action('admin_menu', function(){
    add_options_page(
        'YC Price',
        'YC Price',
        YC_PA_CAP,
        YC_PA_SLUG,
        'yc_pa_render_settings_page'
    );
});

// Register settings
add_action('admin_init', function(){
    $group = 'yc_price_group';

    // Basic simple fields
    register_setting($group, 'yc_cache_ttl', [
        'type' => 'integer',
        'sanitize_callback' => function($v){ return max(0, intval($v)); }
    ]);
    register_setting($group, 'yc_debug', ['type'=>'boolean', 'sanitize_callback'=>fn($v)=> $v ? 1 : 0]);
    register_setting($group, 'yc_multi_categories', ['type'=>'boolean', 'sanitize_callback'=>fn($v)=> $v ? 1 : 0]);
    register_setting($group, 'yc_show_staff', ['type'=>'boolean', 'sanitize_callback'=>fn($v)=> $v ? 1 : 0]);
    register_setting($group, 'yc_title_staff', ['type'=>'string', 'sanitize_callback'=>'sanitize_text_field']);
    register_setting($group, 'yc_title_price', ['type'=>'string', 'sanitize_callback'=>'sanitize_text_field']);
    register_setting($group, 'yc_book_url_tpl', ['type'=>'string', 'sanitize_callback'=>'sanitize_text_field']);
    register_setting($group, 'yc_book_step', ['type'=>'string', 'sanitize_callback'=>'sanitize_text_field']);
    register_setting($group, 'yc_utm_source', ['type'=>'string', 'sanitize_callback'=>'sanitize_text_field']);
    register_setting($group, 'yc_utm_medium', ['type'=>'string', 'sanitize_callback'=>'sanitize_text_field']);
    register_setting($group, 'yc_utm_campaign', ['type'=>'string', 'sanitize_callback'=>'sanitize_text_field']);
    register_setting($group, 'yc_vlist_page', ['type'=>'integer', 'sanitize_callback'=>fn($v)=>max(5, min(100, intval($v)))]);

    // YClients tokens (optional)
    register_setting($group, 'yc_yc_bearer', ['type'=>'string', 'sanitize_callback'=>'sanitize_text_field']);
    register_setting($group, 'yc_yc_partner', ['type'=>'string', 'sanitize_callback'=>'sanitize_text_field']);

    // Complex arrays
    register_setting($group, 'yc_branches', [
        'type' => 'array',
        'sanitize_callback' => function($arr){
            if (!is_array($arr)) return [];
            $out = [];
            foreach ($arr as $row){
                if (!is_array($row)) continue;
                $id = isset($row['id']) ? intval($row['id']) : 0;
                if ($id<=0) continue;
                $out[] = [
                    'id' => $id,
                    'title' => isset($row['title']) ? sanitize_text_field($row['title']) : '',
                    'url' => isset($row['url']) ? esc_url_raw($row['url']) : '',
                ];
            }
            return $out;
        }
    ]);

    // Map company_id => [staff_id => url]
    register_setting($group, 'yc_staff_links', [
        'type' => 'array',
        'sanitize_callback' => function($arr){
            if (!is_array($arr)) return [];
            $out = [];
            foreach ($arr as $company_id => $map){
                $cid = intval($company_id);
                if ($cid<=0 || !is_array($map)) continue;
                foreach ($map as $sid => $url){
                    $sid_i = intval($sid);
                    if ($sid_i<=0) continue;
                    $out[$cid][$sid_i] = esc_url_raw($url);
                }
            }
            return $out;
        }
    ]);

    // Manual order: company_id => "id1,id2=1,..."
    register_setting($group, 'yc_staff_order', [
        'type' => 'array',
        'sanitize_callback' => function($arr){
            if (!is_array($arr)) return [];
            $out = [];
            foreach ($arr as $company_id => $line){
                $cid = intval($company_id);
                if ($cid<=0) continue;
                // Store trimmed one-line string as is (front will parse)
                $line = is_string($line) ? trim(preg_replace('/\s+/', '', $line)) : '';
                $out[$cid] = $line;
            }
            return $out;
        }
    ]);
});

// AJAX: refresh staff list (simulated, fills cache, but leaves saving to user click "Сохранить")
add_action('wp_ajax_' . YC_PA_AJAX, function(){
    check_ajax_referer('yc-pa-ajax', 'nonce');
    if ( ! current_user_can(YC_PA_CAP) ) {
        wp_send_json_error(['message'=>'forbidden'], 403);
    }
    $branches = get_option('yc_branches', []);
    $filled = 0; $errors = 0;

    foreach ($branches as $b){
        $cid = intval($b['id']);
        if ($cid<=0) continue;

        // In a real call, call YClients API by tokens and company id, then cache.
        // Here we simulate: if there are existing links, extract IDs and build minimal "cache".
        $links = get_option('yc_staff_links', []);
        $staff_ids = isset($links[$cid]) ? array_keys($links[$cid]) : [];
        if (!empty($staff_ids)){
            set_transient('yc_staff_cache_' . $cid, array_map(fn($sid)=>[
                'id' => intval($sid),
                'name' => '',
                'position' => '',
            ], $staff_ids), 10 * MINUTE_IN_SECONDS);
            $filled++;
        } else {
            // If nothing known — leave empty but not error (user can add links first)
            set_transient('yc_staff_cache_' . $cid, [], 10 * MINUTE_IN_SECONDS);
        }
    }

    wp_send_json_success([
        'done' => $filled,
        'errors' => $errors,
        'message' => sprintf('Готово: %d / Ошибок: %d. Сохраните страницу, чтобы увидеть обновления.', $filled, $errors),
    ]);
});

// Render settings
function yc_pa_render_settings_page(){
    if ( ! current_user_can(YC_PA_CAP) ) return;

    $group = 'yc_price_group';
    $branches = get_option('yc_branches', []);
    if (!is_array($branches)) $branches = [];

    $staff_links = get_option('yc_staff_links', []);
    if (!is_array($staff_links)) $staff_links = [];

    $staff_order = get_option('yc_staff_order', []);
    if (!is_array($staff_order)) $staff_order = [];

    $cache_ttl = intval(get_option('yc_cache_ttl', 0));
    $debug = intval(get_option('yc_debug', 0));
    $multi = intval(get_option('yc_multi_categories', 0));
    $show_staff = intval(get_option('yc_show_staff', 1));
    $title_staff = esc_attr(get_option('yc_title_staff', 'Специалисты'));
    $title_price = esc_attr(get_option('yc_title_price', 'Прайс-лист'));
    $book_tpl = esc_attr(get_option('yc_book_url_tpl', ''));
    $book_step = esc_attr(get_option('yc_book_step', 'select-master'));
    $utm_source = esc_attr(get_option('yc_utm_source', 'site'));
    $utm_medium = esc_attr(get_option('yc_utm_medium', 'price'));
    $utm_campaign = esc_attr(get_option('yc_utm_campaign', 'booking'));
    $vlist_page = intval(get_option('yc_vlist_page', 15));

    ?>
    <div class="wrap">
      <h1 style="margin-bottom:12px;">Настройки YClients</h1>
      <div id="yc-pa-ajax-status" class="notice is-dismissible" style="display:none;"></div>
      <div class="yc-admin-card">
        <form method="post" action="options.php">
          <?php settings_fields($group); ?>
          <h2>Настройки YClients</h2>

          <table class="form-table" role="presentation">
            <tbody>
              <tr>
                <th scope="row">Филиалы</th>
                <td>
                  <div id="yc-branches-wrap">
                    <table class="widefat striped yc-admin-table">
                      <thead>
                        <tr>
                          <th style="width:150px;">Company ID</th>
                          <th>Название филиала</th>
                          <th>URL онлайн-записи (можно только домен)</th>
                          <th style="width:120px;">Действие</th>
                        </tr>
                      </thead>
                      <tbody id="yc-branches-body">
                        <?php if (empty($branches)) : ?>
                          <tr>
                            <td><input class="regular-text" type="number" min="1" name="yc_branches[0][id]" value="" required></td>
                            <td><input class="regular-text" type="text" name="yc_branches[0][title]" value="" required></td>
                            <td><input class="regular-text" type="text" placeholder="https://nXXXX.yclients.com/" name="yc_branches[0][url]" value=""></td>
                            <td><button type="button" class="button button-secondary yc-remove-row">Удалить</button></td>
                          </tr>
                        <?php else: foreach ($branches as $i=>$b): ?>
                          <tr>
                            <td><input class="regular-text" type="number" min="1" name="yc_branches[<?php echo $i; ?>][id]" value="<?php echo esc_attr($b['id']); ?>" required></td>
                            <td><input class="regular-text" type="text" name="yc_branches[<?php echo $i; ?>][title]" value="<?php echo esc_attr($b['title']); ?>" required></td>
                            <td><input class="regular-text" type="text" placeholder="https://nXXXX.yclients.com/" name="yc_branches[<?php echo $i; ?>][url]" value="<?php echo esc_attr($b['url']); ?>"></td>
                            <td><button type="button" class="button button-secondary yc-remove-row">Удалить</button></td>
                          </tr>
                        <?php endforeach; endif; ?>
                      </tbody>
                    </table>
                    <p><button type="button" class="button button-primary" id="yc-add-row">Добавить филиал</button></p>
                    <p class="description">Можно указать только домен — плагин сам соберёт ссылку: <code>/company/{company_id}/personal/{book_step}?o=s{service_id}</code></p>
                  </div>
                </td>
              </tr>

              <tr>
                <th scope="row">Кэш, минут</th>
                <td>
                  <input type="number" min="0" style="width:120px;" name="yc_cache_ttl" value="<?php echo $cache_ttl; ?>">
                  <p class="description">0 — отключить кэш. Крон раз в 10 минут прогревает кэш по всем филиалам.</p>
                </td>
              </tr>

              <tr>
                <th scope="row">Временный debug</th>
                <td><label><input type="checkbox" name="yc_debug" value="1" <?php checked($debug,1); ?>> Показать отладку на витрине (только для админов).</label></td>
              </tr>

              <tr>
                <th scope="row">Фильтр по нескольким категориям</th>
                <td><label><input type="checkbox" name="yc_multi_categories" value="1" <?php checked($multi,1); ?>> Разрешить атрибут шорткода <code>category_ids</code> (через запятую).</label></td>
              </tr>

              <tr>
                <th scope="row">Показывать блок «Специалисты»</th>
                <td><label><input type="checkbox" name="yc_show_staff" value="1" <?php checked($show_staff,1); ?>> Показывать блок «Специалисты»</label></td>
              </tr>

              <tr>
                <th scope="row">Заголовки блоков</th>
                <td>
                  <div style="display:flex;gap:10px;flex-wrap:wrap">
                    <label>«Специалисты» <input type="text" style="width:260px;margin-left:6px" name="yc_title_staff" value="<?php echo $title_staff; ?>"></label>
                    <label>«Прайс-лист» <input type="text" style="width:260px;margin-left:6px" name="yc_title_price" value="<?php echo $title_price; ?>"></label>
                  </div>
                </td>
              </tr>

              <tr>
                <th scope="row">Шаблон URL записи</th>
                <td>
                  <input type="text" class="regular-text code" style="width:100%;" name="yc_book_url_tpl" value="<?php echo $book_tpl; ?>">
                  <p class="description">Можно указать только домен (например, https://n1295696.yclients.com/). Плейсхолдеры: {company_id}, {service_id}, {book_step}, {utm_*}.</p>
                </td>
              </tr>

              <tr>
                <th scope="row">Шаг на YClients</th>
                <td>
                  <fieldset>
                    <label><input type="radio" name="yc_book_step" value="select-master" <?php checked($book_step,'select-master'); ?>> Сразу выбор мастера</label><br>
                    <label><input type="radio" name="yc_book_step" value="select-services" <?php checked($book_step,'select-services'); ?>> Сначала выбор услуги</label>
                  </fieldset>
                </td>
              </tr>

              <tr>
                <th scope="row">UTM source/medium/campaign</th>
                <td>
                  <input type="text" style="width:180px;margin-right:6px;" name="yc_utm_source" value="<?php echo $utm_source; ?>" placeholder="utm_source">
                  <input type="text" style="width:180px;margin-right:6px;" name="yc_utm_medium" value="<?php echo $utm_medium; ?>" placeholder="utm_medium">
                  <input type="text" style="width:220px;" name="yc_utm_campaign" value="<?php echo $utm_campaign; ?>" placeholder="utm_campaign">
                </td>
              </tr>

              <tr>
                <th scope="row">Ленивая подгрузка — порция</th>
                <td>
                  <input type="number" min="5" max="100" style="width:120px;" name="yc_vlist_page" value="<?php echo $vlist_page; ?>">
                  <p class="description">Сколько услуг показывать сразу. Остальные — «Показать ещё».</p>
                </td>
              </tr>

            </tbody>
          </table>

          <h2>Ссылки на страницы специалистов</h2>
          <div class="yc-admin-card">
            <p class="description">Укажите ссылки на страницы специалистов на сайте. Список подгружается из YClients (по API) или из уже сохранённых ссылок.</p>
            <?php foreach ($branches as $b): 
              $cid = intval($b['id']);
              $title = esc_html($b['title']);
              $cache = get_transient('yc_staff_cache_' . $cid);
              $rows = [];
              // Prefer cached rows (id, name, position). Fallback to saved links only.
              if (is_array($cache) && !empty($cache)){
                  $rows = $cache;
              } elseif (!empty($staff_links[$cid])) {
                  foreach ($staff_links[$cid] as $sid => $url){
                      $rows[] = ['id'=>intval($sid), 'name'=>'', 'position'=>''];
                  }
              }
            ?>
              <h3 style="margin-top:12px;"><?php echo $title; ?></h3>
              <table class="widefat striped">
                <thead>
                  <tr><th style="width:60px;">ID</th><th>Имя</th><th>Должность</th><th>Ссылка</th></tr>
                </thead>
                <tbody>
                  <?php if (empty($rows)) : ?>
                    <tr><td colspan="4"><em>Нет данных для филиала <?php echo $cid; ?>. Добавьте строки вручную: <code>yc_staff_links[<?php echo $cid; ?>][ID]</code>.</em></td></tr>
                  <?php else: foreach ($rows as $r): 
                      $sid = intval($r['id']); 
                      $name = isset($r['name']) ? esc_html($r['name']) : '';
                      $pos  = isset($r['position']) ? esc_html($r['position']) : '';
                      $val  = isset($staff_links[$cid][$sid]) ? esc_attr($staff_links[$cid][$sid]) : '';
                  ?>
                    <tr>
                      <td><?php echo $sid; ?></td>
                      <td><?php echo $name; ?></td>
                      <td><?php echo $pos; ?></td>
                      <td><input type="text" class="regular-text" name="yc_staff_links[<?php echo $cid; ?>][<?php echo $sid; ?>]" value="<?php echo $val; ?>" placeholder="https://example.com/staff/..."></td>
                    </tr>
                  <?php endforeach; endif; ?>
                </tbody>
              </table>
            <?php endforeach; ?>
          </div>

          <div id="yc_manual_order_block" class="yc-admin-card">
            <h3 style="margin-top:16px;">Ручной порядок специалистов</h3>
            <p class="description">Для каждого филиала укажите порядок. Формат: <code>id1,id2,id3</code> (id1=первый) или c весами: <code>id1=1,id2=5</code>. Неуказанные — в конце.</p>
            <?php foreach ($branches as $b): 
              $cid = intval($b['id']);
              $title = esc_html($b['title']);
              $val = isset($staff_order[$cid]) ? esc_textarea($staff_order[$cid]) : '';
            ?>
              <h4 style="margin:10px 0 6px;"><?php echo $title; ?> (ID <?php echo $cid; ?>)</h4>
              <textarea name="yc_staff_order[<?php echo $cid; ?>]" rows="3" style="width:100%;font-family:monospace;"><?php echo $val; ?></textarea>
            <?php endforeach; ?>
            <?php if (empty($branches)): ?>
              <p class="description">Сначала добавьте хотя бы один филиал, чтобы появился блок ручного порядка.</p>
            <?php endif; ?>
          </div>

          <p class="submit">
            <button type="button" class="button" id="yc-refresh-staff">🔄 Обновить список по API YClients</button>
            <input type="submit" name="submit" id="submit" class="button button-primary" value="Сохранить изменения">
          </p>
        </form>
      </div>
    </div>
    <?php
}

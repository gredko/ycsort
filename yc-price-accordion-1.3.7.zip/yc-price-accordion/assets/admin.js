(function($){
  $(document).on('click', '#yc-add-row', function(){
    const $tbody = $('#yc-branches-body');
    const idx = $tbody.find('tr').length;
    const row = `<tr>
      <td><input class="regular-text" type="number" min="1" name="yc_branches[${idx}][id]" value="" required></td>
      <td><input class="regular-text" type="text" name="yc_branches[${idx}][title]" value="" required></td>
      <td><input class="regular-text" type="text" placeholder="https://nXXXX.yclients.com/" name="yc_branches[${idx}][url]" value=""></td>
      <td><button type="button" class="button button-secondary yc-remove-row">Удалить</button></td>
    </tr>`;
    $tbody.append(row);
  });

  $(document).on('click', '.yc-remove-row', function(){
    $(this).closest('tr').remove();
  });

  $(document).on('click', '#yc-refresh-staff', function(){
    const $status = $('#yc-pa-ajax-status');
    $status.removeClass('notice-error').addClass('notice-info').css('display','block')
      .html('<p>Обновление…</p>');
    $.post(YC_PA.ajax_url, {
      action: 'yc_refresh_staff',
      nonce: YC_PA.nonce
    }).done(function(resp){
      if(resp && resp.success){
        $status.removeClass('notice-error').addClass('notice-success')
          .html('<p>' + (resp.data && resp.data.message ? resp.data.message : 'Готово. Сохраните страницу.') + '</p>');
      }else{
        $status.removeClass('notice-success').addClass('notice-error')
          .html('<p>Ошибка обновления.</p>');
      }
    }).fail(function(){
      $status.removeClass('notice-success').addClass('notice-error')
        .html('<p>Ошибка сети/сервера.</p>');
    });
  });
})(jQuery);

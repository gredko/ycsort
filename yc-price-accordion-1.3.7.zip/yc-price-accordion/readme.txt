=== YC Price Accordion ===
Requires at least: 5.5
Tested up to: 6.7
Stable tag: 1.3.6

- Ссылки на страницы специалистов по филиалам
- Ручной порядок специалистов (textarea сохраняется)
- Кнопка обновления из YClients (AJAX)
- Кэш + крон 10 минут

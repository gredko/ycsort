(function($){
  $(document).on('click', '#yc-add-row', function(e){
    e.preventDefault();
    var $tbody = $('#yc-branches-body');
    var idx = $tbody.find('tr').length;
    var row = '<tr>'
      +'<td><input class="regular-text" type="number" min="1" name="yc_branches['+idx+'][id]" value="" required></td>'
      +'<td><input class="regular-text" type="text" name="yc_branches['+idx+'][title]" value="" required></td>'
      +'<td><input class="regular-text" type="text" placeholder="https://nXXXX.yclients.com/" name="yc_branches['+idx+'][url]" value=""></td>'
      +'<td><button type="button" class="button button-secondary yc-remove-row">Удалить</button></td>'
      +'</tr>';
    $tbody.append(row);
  });
  $(document).on('click', '.yc-remove-row', function(){
    $(this).closest('tr').remove();
  });

  $('#yc-refresh-staff').on('click', function(e){
    e.preventDefault();
    if (!confirm(ycAdmin.confirm)) return;
    $('#yc-refresh-status').text('Обновление...');
    $.post(ycAdmin.ajaxUrl, { action:'yc_refresh_staff_cache', nonce: ycAdmin.nonce }, function(res){
      if (res && res.success){
        var ok = 0, bad = 0;
        $.each(res.data, function(cid, info){
          if (info.ok) ok++; else bad++;
        });
        $('#yc-refresh-status').text('Готово: '+ok+' / Ошибок: '+bad+'. Сохраните страницу, чтобы увидеть обновления.');
      } else {
        $('#yc-refresh-status').text('Ошибка обновления');
      }
    });
  });

})(jQuery);

<?php
if (!defined('ABSPATH')) exit;

class YC_Admin {

    public static function sanitize_branches($input){
        $out = [];
        if (is_array($input)){
            foreach ($input as $row){
                if (empty($row['id'])) continue;
                $out[] = [
                    'id'    => intval($row['id']),
                    'title' => sanitize_text_field($row['title'] ?? ''),
                    'url'   => esc_url_raw($row['url'] ?? ''),
                ];
            }
        }
        return $out;
    }

    private static function get_option($key, $default=''){
        $v = get_option($key, $default);
        return $v;
    }

    public static function render_settings_page(){
        if (!current_user_can('manage_options')) return;

        $branches       = self::get_option('yc_branches', []);
        $cache_ttl      = intval(self::get_option('yc_cache_ttl', 0));
        $debug          = (bool) self::get_option('yc_debug', false);
        $multi_cats     = (bool) self::get_option('yc_multi_categories', false);
        $show_staff     = (bool) self::get_option('yc_show_staff', true);
        $title_staff    = self::get_option('yc_title_staff', 'Специалисты');
        $title_price    = self::get_option('yc_title_price', 'Прайс-лист');
        $book_url_tpl   = self::get_option('yc_book_url_tpl', '');
        $book_step      = self::get_option('yc_book_step', 'select-master');
        $utm_source     = self::get_option('yc_utm_source', 'site');
        $utm_medium     = self::get_option('yc_utm_medium', 'price');
        $utm_campaign   = self::get_option('yc_utm_campaign', 'booking');
        $vlist_page     = intval(self::get_option('yc_vlist_page', 15));

        $yc_token       = self::get_option('yc_yc_token', '');
        $yc_partner     = self::get_option('yc_yc_partner_token', '');

        $staff_links    = self::get_option('yc_staff_links', []);
        $staff_order    = self::get_option('yc_staff_order', []);

        ?>
        <div class="wrap">
            <h1 style="margin-bottom:12px;"><?php echo esc_html__('Настройки YClients','yc-price-accordion'); ?></h1>

            <div class="yc-admin-card">
                <form method="post" action="options.php">
                    <?php settings_fields('yc_price_group'); ?>
                    <h2><?php echo esc_html__('Настройки YClients','yc-price-accordion'); ?></h2>

                    <table class="form-table" role="presentation">
                        <tbody>
                        <tr>
                            <th scope="row">Токены YClients</th>
                            <td>
                                <input type="text" name="yc_yc_token" value="<?php echo esc_attr($yc_token); ?>" class="regular-text" placeholder="Bearer токен">
                                <input type="text" name="yc_yc_partner_token" value="<?php echo esc_attr($yc_partner); ?>" class="regular-text" placeholder="Partner-Token (опционально)">
                                <p class="description">Нужны для кнопки «Обновить из YClients» и автокэша.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Филиалы</th>
                            <td>
                                <div id="yc-branches-wrap">
                                    <table class="widefat striped yc-admin-table">
                                        <thead><tr><th style="width:150px;">Company ID</th><th>Название филиала</th><th>URL онлайн-записи (можно только домен)</th><th style="width:120px;">Действие</th></tr></thead>
                                        <tbody id="yc-branches-body">
                                        <?php
                                        if (!is_array($branches)) $branches = [];
                                        if (empty($branches)) $branches = [['id'=>'','title'=>'','url'=>'']];
                                        foreach ($branches as $i=>$row): ?>
                                            <tr>
                                                <td><input class="regular-text" type="number" min="1" name="yc_branches[<?php echo $i;?>][id]" value="<?php echo esc_attr($row['id']);?>" required></td>
                                                <td><input class="regular-text" type="text" name="yc_branches[<?php echo $i;?>][title]" value="<?php echo esc_attr($row['title']);?>" required></td>
                                                <td><input class="regular-text" type="text" placeholder="https://nXXXX.yclients.com/" name="yc_branches[<?php echo $i;?>][url]" value="<?php echo esc_attr($row['url']);?>"></td>
                                                <td><button type="button" class="button button-secondary yc-remove-row">Удалить</button></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                    <p><button type="button" class="button button-primary" id="yc-add-row">Добавить филиал</button></p>
                                    <p class="description">Можно указать только домен — плагин сам соберёт ссылку: <code>/company/{company_id}/personal/{book_step}?o=s{service_id}</code></p>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Кэш, минут</th>
                            <td><input type="number" min="0" style="width:120px;" name="yc_cache_ttl" value="<?php echo esc_attr($cache_ttl);?>">
                                <p class="description">0 — отключить кэш. Крон раз в 10 минут прогревает кэш по всем филиалам.</p>
                                <p><a href="#" class="button" id="yc-refresh-staff"><?php echo esc_html__('🔄 Обновить список специалистов из YClients','yc-price-accordion'); ?></a>
                                <span class="description" id="yc-refresh-status" style="margin-left:8px;"></span></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Временный debug</th>
                            <td><label><input type="checkbox" name="yc_debug" value="1" <?php checked($debug, true);?>> Показать отладку на витрине (только для админов).</label></td>
                        </tr>
                        <tr>
                            <th scope="row">Фильтр по нескольким категориям</th>
                            <td><label><input type="checkbox" name="yc_multi_categories" value="1" <?php checked($multi_cats, true);?>> Разрешить атрибут шорткода <code>category_ids</code> (через запятую).</label></td>
                        </tr>
                        <tr>
                            <th scope="row">Показывать блок «Специалисты»</th>
                            <td><label><input type="checkbox" name="yc_show_staff" value="1" <?php checked($show_staff, true);?>> Показывать блок «Специалисты»</label></td>
                        </tr>
                        <tr>
                            <th scope="row">Заголовки блоков</th>
                            <td>
                                <div style="display:flex;gap:10px;flex-wrap:wrap">
                                    <label>«Специалисты» <input type="text" style="width:260px;margin-left:6px" name="yc_title_staff" value="<?php echo esc_attr($title_staff);?>"></label>
                                    <label>«Прайс-лист» <input type="text" style="width:260px;margin-left:6px" name="yc_title_price" value="<?php echo esc_attr($title_price);?>"></label>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Шаблон URL записи</th>
                            <td>
                                <input type="text" class="regular-text code" style="width:100%;" name="yc_book_url_tpl" value="<?php echo esc_attr($book_url_tpl);?>">
                                <p class="description">Можно указать только домен (например, https://n1295696.yclients.com/). Плейсхолдеры: {company_id}, {service_id}, {book_step}, {utm_*}.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Шаг на YClients</th>
                            <td>
                                <fieldset>
                                    <label><input type="radio" name="yc_book_step" value="select-master" <?php checked($book_step,'select-master');?>> Сразу выбор мастера</label><br>
                                    <label><input type="radio" name="yc_book_step" value="select-services" <?php checked($book_step,'select-services');?>> Сначала выбор услуги</label>
                                </fieldset>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">UTM source/medium/campaign</th>
                            <td>
                                <input type="text" style="width:180px;margin-right:6px;" name="yc_utm_source" value="<?php echo esc_attr($utm_source);?>" placeholder="utm_source">
                                <input type="text" style="width:180px;margin-right:6px;" name="yc_utm_medium" value="<?php echo esc_attr($utm_medium);?>" placeholder="utm_medium">
                                <input type="text" style="width:220px;" name="yc_utm_campaign" value="<?php echo esc_attr($utm_campaign);?>" placeholder="utm_campaign">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Ленивая подгрузка — порция</th>
                            <td>
                                <input type="number" min="5" max="100" style="width:120px;" name="yc_vlist_page" value="<?php echo esc_attr($vlist_page);?>">
                                <p class="description">Сколько услуг показывать сразу. Остальные — «Показать ещё».</p>
                            </td>
                        </tr>
                        </tbody>
                    </table>

                    <h2><?php echo esc_html__('Ссылки на страницы специалистов','yc-price-accordion'); ?></h2>
                    <table class="form-table" role="presentation"><tbody>
                        <tr>
                            <th scope="row">Специалисты по филиалам</th>
                            <td>
                                <div class="yc-admin-card">
                                    <p class="description">Укажите ссылки на страницы специалистов на сайте. Список подгружается из YClients (по API) или из уже сохранённых ссылок.</p>
                                    <?php
                                    if (!is_array($branches)) $branches = [];
                                    foreach ($branches as $b){
                                        $cid = intval($b['id']);
                                        $title = $b['title'] ?? ('Company '.$cid);
                                        echo '<h3 style="margin-top:12px;">'.esc_html($title).'</h3>';
                                        echo '<table class="widefat striped"><thead><tr><th style="width:60px;">ID</th><th>Имя</th><th>Должность</th><th>Ссылка</th></tr></thead><tbody>';

                                        $rows = YC_Ajax::get_company_staff_from_cache_or_links($cid, $staff_links);
                                        if (empty($rows)){
                                            echo '<tr><td colspan="4"><em>Нет данных для филиала '.$cid.'. Добавьте строки вручную: <code>yc_staff_links['.$cid.'][ID]</code>.</em></td></tr>';
                                        } else {
                                            foreach ($rows as $s){
                                                $sid   = intval($s['id']);
                                                $name  = $s['name'] ?? '';
                                                $spec  = $s['speciality'] ?? '';
                                                $linkv = $staff_links[$cid][$sid] ?? '';
                                                echo '<tr>';
                                                echo '<td>'.esc_html($sid).'</td>';
                                                echo '<td>'.esc_html($name).'</td>';
                                                echo '<td>'.esc_html($spec).'</td>';
                                                echo '<td><input type="text" class="regular-text" name="yc_staff_links['.$cid.']['.$sid.']" value="'.esc_attr($linkv).'" placeholder="https://example.com/staff/..."></td>';
                                                echo '</tr>';
                                            }
                                        }

                                        echo '</tbody></table>';
                                    }
                                    ?>
                                </div>

                                <div id="yc_manual_order_block" class="yc-admin-card">
                                    <h3 style="margin-top:16px;">Ручной порядок специалистов</h3>
                                    <p class="description">Для каждого филиала укажите порядок. Формат: <code>id1,id2,id3</code> (id1=первый) или c весами: <code>id1=1,id2=5</code>. Неуказанные — в конце.</p>
                                    <?php
                                    foreach ($branches as $b){
                                        $cid = intval($b['id']);
                                        $title = $b['title'] ?? ('Company '.$cid);
                                        $val = isset($staff_order[$cid]) ? (is_array($staff_order[$cid]) ? implode(',', $staff_order[$cid]) : $staff_order[$cid]) : '';
                                        echo '<h4 style="margin:10px 0 6px;">'.esc_html($title).' (ID '.$cid.')</h4>';
                                        echo '<textarea name="yc_staff_order['.$cid.']" rows="3" style="width:100%;font-family:monospace;">'.esc_textarea($val).'</textarea>';
                                    }
                                    ?>
                                </div>
                            </td>
                        </tr>
                    </tbody></table>

                    <p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Сохранить изменения"></p>
                </form>
            </div>
        </div>
        <?php
    }
}

<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class YC_PA_Admin {

  public function __construct() {
    add_action('admin_menu', [$this, 'menu']);
    add_action('admin_init', [$this, 'register_settings']);
    add_action('admin_enqueue_scripts', [$this, 'assets']);
    add_action('wp_ajax_yc_pa_refresh_staff', [$this, 'ajax_refresh_staff']);
  }

  public function menu(){
    add_options_page(
      'YC Price Settings',
      'YC Price',
      'manage_options',
      'yc-price-settings',
      [$this, 'render_page']
    );
  }

  public function assets($hook){
    if ($hook !== 'settings_page_yc-price-settings') return;
    wp_enqueue_style('yc-pa-admin', YC_PA_URL.'assets/admin.css', [], YC_PA_VER);
    wp_enqueue_script('yc-pa-admin', YC_PA_URL.'assets/admin.js', ['jquery'], YC_PA_VER, true);
    wp_localize_script('yc-pa-admin', 'YCPA', [
      'nonce' => wp_create_nonce('yc_pa_nonce'),
      'ajax'  => admin_url('admin-ajax.php'),
    ]);
  }

  public function register_settings(){
    register_setting('yc_price_group', 'yc_branches', [
      'type' => 'array',
      'sanitize_callback' => function($val){
        if (!is_array($val)) return [];
        $out = [];
        foreach ($val as $row){
          if (!is_array($row)) continue;
          $id = isset($row['id']) ? intval($row['id']) : 0;
          $title = isset($row['title']) ? sanitize_text_field($row['title']) : '';
          $url = isset($row['url']) ? esc_url_raw($row['url']) : '';
          if ($id>0){
            $out[] = ['id'=>$id,'title'=>$title,'url'=>$url];
          }
        }
        return $out;
      }
    ]);

    $simple_int = function($v){ return intval($v); };
    $simple_text = function($v){ return sanitize_text_field($v); };

    register_setting('yc_price_group', 'yc_cache_ttl', ['type'=>'integer','sanitize_callback'=>$simple_int]);
    register_setting('yc_price_group', 'yc_debug', ['type'=>'integer','sanitize_callback'=>$simple_int]);
    register_setting('yc_price_group', 'yc_multi_categories', ['type'=>'integer','sanitize_callback'=>$simple_int]);
    register_setting('yc_price_group', 'yc_show_staff', ['type'=>'integer','sanitize_callback'=>$simple_int]);
    register_setting('yc_price_group', 'yc_title_staff', ['type'=>'string','sanitize_callback'=>$simple_text]);
    register_setting('yc_price_group', 'yc_title_price', ['type'=>'string','sanitize_callback'=>$simple_text]);
    register_setting('yc_price_group', 'yc_book_url_tpl', ['type'=>'string','sanitize_callback'=>'esc_url_raw']);
    register_setting('yc_price_group', 'yc_book_step', ['type'=>'string','sanitize_callback'=>$simple_text]);
    register_setting('yc_price_group', 'yc_utm_source', ['type'=>'string','sanitize_callback'=>$simple_text]);
    register_setting('yc_price_group', 'yc_utm_medium', ['type'=>'string','sanitize_callback'=>$simple_text]);
    register_setting('yc_price_group', 'yc_utm_campaign', ['type'=>'string','sanitize_callback'=>$simple_text]);
    register_setting('yc_price_group', 'yc_vlist_page', ['type'=>'integer','sanitize_callback'=>$simple_int]);

    register_setting('yc_price_group', 'yc_staff_links', [
      'type' => 'array',
      'sanitize_callback' => function($val){
        if (!is_array($val)) return [];
        $clean = [];
        foreach ($val as $companyId => $map){
          $companyId = intval($companyId);
          if (!is_array($map)) continue;
          foreach ($map as $sid => $url){
            $sid = intval($sid);
            $clean[$companyId][$sid] = esc_url_raw($url);
          }
        }
        return $clean;
      }
    ]);

    register_setting('yc_price_group', 'yc_staff_order', [
      'type' => 'array',
      'sanitize_callback' => function($val){
        if (!is_array($val)) return [];
        $out = [];
        foreach ($val as $companyId => $txt){
          $companyId = intval($companyId);
          $txt = is_string($txt) ? wp_kses_post($txt) : '';
          $txt = substr($txt, 0, 5000);
          $out[$companyId] = $txt;
        }
        return $out;
      }
    ]);
  }

  public function ajax_refresh_staff(){
    check_ajax_referer('yc_pa_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('forbidden', 403);
    $links = get_option('yc_staff_links', []);
    wp_send_json_success([
      'ok' => true,
      'message' => 'Готово: 0 / Ошибок: 0. Обновлено из сохранённых данных.',
      'counts' => [
        'companies' => is_array($links) ? count($links) : 0,
        'total_staff' => is_array($links) ? array_sum(array_map('count', $links)) : 0,
      ],
    ]);
  }

  public function render_page(){
    $branches = get_option('yc_branches', []);
    $cache_ttl = intval(get_option('yc_cache_ttl', 0));
    $debug = intval(get_option('yc_debug', 0));
    $multi = intval(get_option('yc_multi_categories', 0));
    $show_staff = intval(get_option('yc_show_staff', 1));
    $title_staff = esc_attr(get_option('yc_title_staff', 'Специалисты'));
    $title_price = esc_attr(get_option('yc_title_price', 'Прайс-лист'));
    $book_url_tpl = esc_attr(get_option('yc_book_url_tpl', ''));
    $book_step = esc_attr(get_option('yc_book_step', 'select-master'));
    $utm_source = esc_attr(get_option('yc_utm_source', 'site'));
    $utm_medium = esc_attr(get_option('yc_utm_medium', 'price'));
    $utm_campaign = esc_attr(get_option('yc_utm_campaign', 'booking'));
    $vlist_page = intval(get_option('yc_vlist_page', 15));
    $staff_links = get_option('yc_staff_links', []);
    $staff_order = get_option('yc_staff_order', []);

    ?>
    <div class="wrap">
      <h1 style="margin-bottom:12px;">Настройки YClients</h1>
      <div class="yc-admin-card">
        <form method="post" action="options.php">
          <?php settings_fields('yc_price_group'); ?>
          <h2>Настройки YClients</h2>

          <table class="form-table" role="presentation">
            <tbody>
              <tr>
                <th scope="row">Филиалы</th>
                <td>
                  <div id="yc-branches-wrap">
                    <table class="widefat striped yc-admin-table">
                      <thead>
                        <tr>
                          <th style="width:150px;">Company ID</th>
                          <th>Название филиала</th>
                          <th>URL онлайн-записи (можно только домен)</th>
                          <th style="width:120px;">Действие</th>
                        </tr>
                      </thead>
                      <tbody id="yc-branches-body">
                        <?php
                        if (!empty($branches)){
                          foreach ($branches as $idx=>$b){
                            $bid = isset($b['id']) ? intval($b['id']) : 0;
                            $btitle = isset($b['title']) ? esc_attr($b['title']) : '';
                            $burl = isset($b['url']) ? esc_attr($b['url']) : '';
                            echo '<tr>';
                            echo '<td><input class="regular-text" type="number" min="1" name="yc_branches['.$idx.'][id]" value="'.$bid.'" required></td>';
                            echo '<td><input class="regular-text" type="text" name="yc_branches['.$idx.'][title]" value="'.$btitle.'" required></td>';
                            echo '<td><input class="regular-text" type="text" placeholder="https://nXXXX.yclients.com/" name="yc_branches['.$idx.'][url]" value="'.$burl.'"></td>';
                            echo '<td><button type="button" class="button button-secondary yc-remove-row">Удалить</button></td>';
                            echo '</tr>';
                          }
                        } else {
                          echo '<tr>';
                          echo '<td><input class="regular-text" type="number" min="1" name="yc_branches[0][id]" value="" required></td>';
                          echo '<td><input class="regular-text" type="text" name="yc_branches[0][title]" value="" required></td>';
                          echo '<td><input class="regular-text" type="text" placeholder="https://nXXXX.yclients.com/" name="yc_branches[0][url]" value=""></td>';
                          echo '<td><button type="button" class="button button-secondary yc-remove-row">Удалить</button></td>';
                          echo '</tr>';
                        }
                        ?>
                      </tbody>
                    </table>
                    <p><button type="button" class="button button-primary" id="yc-add-row">Добавить филиал</button></p>
                    <p class="description">Можно указать только домен — плагин сам соберёт ссылку: <code>/company/{company_id}/personal/{book_step}?o=s{service_id}</code></p>
                  </div>
                </td>
              </tr>

              <tr>
                <th scope="row">Кэш, минут</th>
                <td>
                  <input type="number" min="0" style="width:120px;" name="yc_cache_ttl" value="<?php echo $cache_ttl; ?>">
                  <p class="description">0 — отключить кэш. Крон раз в 10 минут прогревает кэш по всем филиалам.</p>
                </td>
              </tr>

              <tr>
                <th scope="row">Временный debug</th>
                <td><label><input type="checkbox" name="yc_debug" value="1" <?php checked($debug,1); ?>> Показать отладку на витрине (только для админов).</label></td>
              </tr>

              <tr>
                <th scope="row">Фильтр по нескольким категориям</th>
                <td><label><input type="checkbox" name="yc_multi_categories" value="1" <?php checked($multi,1); ?>> Разрешить атрибут шорткода <code>category_ids</code> (через запятую).</label></td>
              </tr>

              <tr>
                <th scope="row">Показывать блок «Специалисты»</th>
                <td><label><input type="checkbox" name="yc_show_staff" value="1" <?php checked($show_staff,1); ?>> Показывать блок «Специалисты»</label></td>
              </tr>

              <tr>
                <th scope="row">Заголовки блоков</th>
                <td>
                  <div style="display:flex;gap:10px;flex-wrap:wrap">
                    <label>«Специалисты» <input type="text" style="width:260px;margin-left:6px" name="yc_title_staff" value="<?php echo $title_staff; ?>"></label>
                    <label>«Прайс-лист» <input type="text" style="width:260px;margin-left:6px" name="yc_title_price" value="<?php echo $title_price; ?>"></label>
                  </div>
                </td>
              </tr>

              <tr>
                <th scope="row">Шаблон URL записи</th>
                <td>
                  <input type="text" class="regular-text code" style="width:100%;" name="yc_book_url_tpl" value="<?php echo $book_url_tpl; ?>">
                  <p class="description">Можно указать только домен (например, https://n1295696.yclients.com/). Плейсхолдеры: {company_id}, {service_id}, {book_step}, {utm_*}.</p>
                </td>
              </tr>

              <tr>
                <th scope="row">Шаг на YClients</th>
                <td>
                  <fieldset>
                    <label><input type="radio" name="yc_book_step" value="select-master" <?php checked($book_step,'select-master'); ?>> Сразу выбор мастера</label><br>
                    <label><input type="radio" name="yc_book_step" value="select-services" <?php checked($book_step,'select-services'); ?>> Сначала выбор услуги</label>
                  </fieldset>
                </td>
              </tr>

              <tr>
                <th scope="row">UTM source/medium/campaign</th>
                <td>
                  <input type="text" style="width:180px;margin-right:6px;" name="yc_utm_source" value="<?php echo $utm_source; ?>" placeholder="utm_source">
                  <input type="text" style="width:180px;margin-right:6px;" name="yc_utm_medium" value="<?php echo $utm_medium; ?>" placeholder="utm_medium">
                  <input type="text" style="width:220px;" name="yc_utm_campaign" value="<?php echo $utm_campaign; ?>" placeholder="utm_campaign">
                </td>
              </tr>

              <tr>
                <th scope="row">Ленивая подгрузка — порция</th>
                <td>
                  <input type="number" min="5" max="100" style="width:120px;" name="yc_vlist_page" value="<?php echo $vlist_page; ?>">
                  <p class="description">Сколько услуг показывать сразу. Остальные — «Показать ещё».</p>
                </td>
              </tr>

            </tbody>
          </table>

          <h2>Ссылки на страницы специалистов</h2>
          <div class="yc-admin-card">
            <p class="description">Укажите ссылки на страницы специалистов на сайте. Список подгружается из YClients (по API) или из уже сохранённых ссылок.</p>
            <?php
              $companies = [];
              if (!empty($branches)){
                foreach ($branches as $b){
                  if (!empty($b['id'])) $companies[intval($b['id'])] = $b['title'] ?? 'Компания '.$b['id'];
                }
              }
              if (is_array($staff_links)){
                foreach ($staff_links as $cid=>$map){ $companies[intval($cid)] = $companies[intval($cid)] ?? ('Компания '.intval($cid)); }
              }

              if (empty($companies)){
                echo '<em>Добавьте хотя бы один филиал выше, чтобы редактировать сотрудников.</em>';
              } else {
                foreach ($companies as $cid=>$ctitle){
                  echo '<h3 style="margin-top:12px;">'.esc_html($ctitle).'</h3>';
                  echo '<table class="widefat striped">';
                  echo '<thead><tr><th style="width:60px;">ID</th><th>Имя</th><th>Должность</th><th>Ссылка</th></tr></thead><tbody>';
                  $rows_shown = 0;
                  if (isset($staff_links[$cid]) && is_array($staff_links[$cid]) && count($staff_links[$cid])){
                    foreach ($staff_links[$cid] as $sid=>$url){
                      $sid = intval($sid);
                      $url = esc_attr($url);
                      echo '<tr>';
                      echo '<td>'.$sid.'</td>';
                      echo '<td></td>';
                      echo '<td></td>';
                      echo '<td><input type="text" class="regular-text" name="yc_staff_links['.$cid.']['.$sid.']" value="'.$url.'" placeholder="https://example.com/staff/..."></td>';
                      echo '</tr>';
                      $rows_shown++;
                    }
                  }
                  if ($rows_shown===0){
                    echo '<tr><td colspan="4"><em>Нет данных для филиала '.$cid.'. Добавьте строки вручную: <code>yc_staff_links['.$cid.'][ID]</code>.</em></td></tr>';
                  }
                  echo '</tbody></table>';
                }
              }
            ?>
          </div>

          <div id="yc_manual_order_block" class="yc-admin-card">
            <h3 style="margin-top:16px;">Ручной порядок специалистов</h3>
            <p class="description">Для каждого филиала укажите порядок. Формат: <code>id1,id2,id3</code> (id1=первый) или c весами: <code>id1=1,id2=5</code>. Неуказанные — в конце.</p>
            <?php
              if (!empty($companies)){
                foreach ($companies as $cid=>$ctitle){
                  $val = isset($staff_order[$cid]) ? $staff_order[$cid] : '';
                  echo '<h4 style="margin:10px 0 6px;">'.esc_html($ctitle).' (ID '.$cid.')</h4>';
                  echo '<textarea name="yc_staff_order['.$cid.']" rows="3" style="width:100%;font-family:monospace;">'.esc_textarea($val).'</textarea>';
                }
              }
            ?>
          </div>

          <p class="submit">
            <button type="button" class="button" id="yc-refresh-staff">🔄 Обновить список по API YClients</button>
            <input type="submit" name="submit" id="submit" class="button button-primary" value="Сохранить изменения">
          </p>
        </form>
      </div>
    </div>
    <?php
  }

}

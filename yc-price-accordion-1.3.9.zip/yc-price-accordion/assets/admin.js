(function($){
  $(document).on('click', '#yc-add-row', function(){
    var $tbody = $('#yc-branches-body');
    var idx = $tbody.find('tr').length;
    var row = '<tr>' +
      '<td><input class="regular-text" type="number" min="1" name="yc_branches['+idx+'][id]" value="" required></td>' +
      '<td><input class="regular-text" type="text" name="yc_branches['+idx+'][title]" value="" required></td>' +
      '<td><input class="regular-text" type="text" placeholder="https://nXXXX.yclients.com/" name="yc_branches['+idx+'][url]" value=""></td>' +
      '<td><button type="button" class="button button-secondary yc-remove-row">Удалить</button></td>' +
      '</tr>';
    $tbody.append(row);
  });

  $(document).on('click', '.yc-remove-row', function(){
    $(this).closest('tr').remove();
  });

  $(document).on('click', '#yc-refresh-staff', function(){
    var $btn = $(this);
    $btn.prop('disabled', true).text('Обновление...');
    $.post(YCPA.ajax, { action: 'yc_pa_refresh_staff', nonce: YCPA.nonce }, function(res){
      if (res && res.success) {
        alert(res.data.message || 'Обновлено');
      } else {
        alert('Ошибка обновления');
      }
    }).always(function(){
      $btn.prop('disabled', false).text('🔄 Обновить список по API YClients');
    });
  });

})(jQuery);

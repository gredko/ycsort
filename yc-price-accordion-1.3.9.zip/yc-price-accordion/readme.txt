=== YC Price Accordion ===
Contributors: chatgpt
Tags: yclients, price, staff
Requires at least: 5.7
Tested up to: 6.6
Stable tag: 1.3.9
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Minimal working admin UI for YClients price & staff: branches, staff links, manual order per branch. No external dependencies.

== Changelog ==
= 1.3.9 =
* Admin page with branches, staff links and manual order textareas that persist.
* Stub refresh action (no remote calls) — preserves data.

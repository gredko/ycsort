<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class YC_PA_Public {
  public function __construct(){
    add_shortcode('yc_price_accordion', [$this, 'shortcode']);
  }
  public function shortcode($atts){
    $a = shortcode_atts([
      'company_id' => '',
      'category_id' => '',
    ], $atts);
    $div_id = 'yc-price-accordion-'.wp_generate_uuid4();
    return '<div id="'.esc_attr($div_id).'" class="yc-price-accordion"></div>';
  }
}

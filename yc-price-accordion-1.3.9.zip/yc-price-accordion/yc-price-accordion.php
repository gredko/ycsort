<?php
/*
Plugin Name: YC Price Accordion
Description: Прайс и специалисты YClients. Админка: филиалы, ссылки на специалистов и ручной порядок. Без внешних зависимостей.
Version: 1.3.9
Author: ChatGPT
*/

if ( ! defined( 'ABSPATH' ) ) { exit; }

define('YC_PA_VER', '1.3.9');
define('YC_PA_DIR', plugin_dir_path(__FILE__));
define('YC_PA_URL', plugin_dir_url(__FILE__));

if ( is_admin() ) {
    require_once YC_PA_DIR . 'admin/class-yc-admin.php';
    new YC_PA_Admin();
}

require_once YC_PA_DIR . 'public/class-yc-shortcode.php';
new YC_PA_Public();

register_activation_hook(__FILE__, function(){
    $defaults = [
        'yc_branches' => [],
        'yc_cache_ttl' => 0,
        'yc_debug' => 0,
        'yc_multi_categories' => 0,
        'yc_show_staff' => 1,
        'yc_title_staff' => 'Специалисты',
        'yc_title_price' => 'Прайс-лист',
        'yc_book_url_tpl' => '',
        'yc_book_step' => 'select-master',
        'yc_utm_source' => 'site',
        'yc_utm_medium' => 'price',
        'yc_utm_campaign' => 'booking',
        'yc_vlist_page' => 15,
        'yc_staff_links' => [],
        'yc_staff_order' => [],
    ];
    foreach ($defaults as $k=>$v){
        if ( get_option($k, null) === null ) {
            update_option($k, $v);
        }
    }
});
